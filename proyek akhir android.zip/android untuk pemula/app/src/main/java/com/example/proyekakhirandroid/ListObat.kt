package com.example.proyekakhirandroid

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView

class ListObat(private val listObat: ArrayList<Obat>) : RecyclerView.Adapter<ListObat.ListViewHolder>() {
    private lateinit var onItemClickCallback:OnItemClickCallBack

    fun setOnItemClickCallBack(onItemClickCallback:OnItemClickCallBack){
        this.onItemClickCallback = onItemClickCallback
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListViewHolder {
        val view:View = LayoutInflater.from(parent.context).inflate(R.layout.item_row_obat,parent,false)
        return ListViewHolder(view)
    }

    override fun getItemCount (): Int = listObat.size

    override fun onBindViewHolder(holder: ListViewHolder, position: Int) {
        val obat = listObat[position]
        holder.imgPhoto.setImageResource(obat.photo)
        holder.tvName.text = obat.name
        holder.tvDescription.text = obat.description
        val (name,description,photo) = listObat[position]
        holder.imgPhoto.setImageResource(photo)
        holder.tvName.text = name
        holder.tvDescription.text = description
        holder.itemView.setOnClickListener {
            val context = holder.itemView.context
            val intent = Intent(context, DetailActivity::class.java).apply {
                putExtra("EXTRA_NAME", obat.name)
                putExtra("EXTRA_DESCRIPTION", obat.description)
                putExtra("EXTRA_PHOTO", obat.photo)
            }
            context.startActivity(intent)
        }
    }

    class ListViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imgPhoto: ImageView = itemView.findViewById(R.id.img_item_photo)
        val tvName: TextView = itemView.findViewById(R.id.tv_item_name)
        val tvDescription: TextView = itemView.findViewById(R.id.tv_item_description)
    }
    interface OnItemClickCallBack{
        fun  onItemClicked(data:Obat)
    }

}