package com.example.proyekakhirandroid

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ObatAdapter(private val listObat: List<Obat>, private val activity: MainActivity) : RecyclerView.Adapter<ObatAdapter.ObatViewHolder>() {

    inner class ObatViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvName: TextView = itemView.findViewById(R.id.tv_item_name)
        val tvDescription: TextView = itemView.findViewById(R.id.tv_item_description)
        val imgPhoto: ImageView = itemView.findViewById(R.id.img_item_photo)

        fun bind(obat: Obat) {
            tvName.text = obat.name
            tvDescription.text = obat.description
            imgPhoto.setImageResource(obat.photo)

            itemView.setOnClickListener {
                val intent = Intent(itemView.context, DetailActivity::class.java)
                intent.putExtra("EXTRA_NAME", obat.name)
                intent.putExtra("EXTRA_DESCRIPTION", obat.description)
                intent.putExtra("EXTRA_PHOTO", obat.photo)
                itemView.context.startActivity(intent)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ObatViewHolder {
        val view: View = LayoutInflater.from(parent.context).inflate(R.layout.item_row_obat, parent, false)
        return ObatViewHolder(view)
    }

    override fun onBindViewHolder(holder: ObatViewHolder, position: Int) {
        holder.bind(listObat[position])
    }

    override fun getItemCount(): Int {
        return listObat.size
    }

}
