package com.example.proyekakhirandroid

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class DetailActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_detail)
        val imageView: ImageView = findViewById(R.id.data_photo)
        val nameTextView: TextView = findViewById(R.id.tv_item_name)
        val descriptionTextView: TextView = findViewById(R.id.tv_item_description)


        val obatName = intent.getStringExtra("EXTRA_NAME")
        val obatDescription = intent.getStringExtra("EXTRA_DESCRIPTION")
        val obatPhoto = intent.getIntExtra("EXTRA_PHOTO", -1)


        if (obatName != null && obatDescription != null && obatPhoto != -1) {
            nameTextView.text = obatName
            descriptionTextView.text = obatDescription
            imageView.setImageResource(obatPhoto)
        } else {

            Log.e("DetailActivity", "Data obat tidak diterima dengan benar")
        }
    }



}