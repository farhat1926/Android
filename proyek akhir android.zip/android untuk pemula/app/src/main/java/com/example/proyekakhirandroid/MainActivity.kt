package com.example.proyekakhirandroid

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.GridLayout
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    private lateinit var rvObat: RecyclerView
    private val list = ArrayList<Obat>()

     fun showSelectedObat(obat: Obat){
        Toast.makeText(this,"Kamu beneran milih ini" + obat.name,Toast.LENGTH_SHORT).show()
        val intent = Intent(this, DetailActivity::class.java)
        intent.putExtra("EXTRA_NAME", obat.name)
        intent.putExtra("EXTRA_DESCRIPTION", obat.description)
        intent.putExtra("EXTRA_PHOTO", obat.photo)
        startActivity(intent)
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        rvObat = findViewById(R.id.rv_obat)
        rvObat.setHasFixedSize(true)

        list.addAll(getListObat())
        showRecyclerList()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_main,menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            R.id.action_profile -> {
                val intent = Intent(this, ProfilActivity::class.java)
                startActivity(intent)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
        return super.onOptionsItemSelected(item)
    }

    private fun getListObat(): ArrayList<Obat>{
        val dataName = resources.getStringArray(R.array.data_name)
        val dataDescription = resources.getStringArray(R.array.data_description)
        val dataPhoto = resources.obtainTypedArray(R.array.data_photo)
        val listObat = ArrayList<Obat>()
        for (i in dataName.indices) {
            val photoResId = dataPhoto.getResourceId(i, -1)
            if (photoResId != -1) {
                val obat = Obat(dataName[i], dataDescription[i], photoResId)
                listObat.add(obat)
            }
        }
        dataPhoto.recycle()
        return listObat
    }
    private fun showRecyclerList(){
        rvObat.layoutManager = LinearLayoutManager(this)
        val listObat = ListObat(list)
        rvObat.adapter = listObat

        listObat.setOnItemClickCallBack((object : ListObat.OnItemClickCallBack{
            override fun onItemClicked(data: Obat) {
                showSelectedObat(data)
            }
        }))
    }

}